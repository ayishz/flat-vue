from django.db import models

# Create your models here.

class login_table(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    type=models.CharField(max_length=100)

class flat_occ_table(models.Model):
    lid=models.ForeignKey(login_table,on_delete=models.CASCADE)

    name=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.IntegerField()
    gender=models.CharField(max_length=100)
    phone=models.BigIntegerField()
    email=models.CharField(max_length=100)
    photo=models.FileField()

class security_table(models.Model):
    lid=models.ForeignKey(login_table,on_delete=models.CASCADE)

    gender = models.CharField(max_length=100)
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.IntegerField()
    phone = models.BigIntegerField()
    email = models.CharField(max_length=100)
    image= models.FileField()

class spot_notn_table(models.Model):
    lid = models.ForeignKey(login_table, on_delete=models.CASCADE)

    notification=models.CharField(max_length=100)
    date=models.DateField()

class complaint_table(models.Model):
    lid = models.ForeignKey(login_table, on_delete=models.CASCADE)

    complaint=models.CharField(max_length=100)
    reply=models.CharField(max_length=100)
    date = models.DateField()

class time_sch_table(models.Model):
    flat_occ = models.ForeignKey(flat_occ_table, on_delete=models.CASCADE)

    date=models.CharField(max_length=100)
    from_time=models.CharField(max_length=100)
    to_time=models.CharField(max_length=100)
    visitor_name=models.CharField(max_length=100)
    no_of_member=models.IntegerField()
    status=models.CharField(max_length=100)

class ser_pro_table(models.Model):
    lid = models.ForeignKey(login_table, on_delete=models.CASCADE)

    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.IntegerField()
    phone = models.BigIntegerField()
    email = models.CharField(max_length=100)
    image = models.FileField()
    gender = models.CharField(max_length=100)

class notn_table(models.Model):
    notification = models.TextField()
    date = models.DateField()

class facilities_table(models.Model):
    ser_pro=models.ForeignKey(ser_pro_table,on_delete=models.CASCADE)

    facility=models.CharField(max_length=100)
    detail=models.CharField(max_length=100)
    date=models.DateField()
    type=models.CharField(max_length=100)
    name=models.CharField(max_length=100)

class medical_store_table(models.Model):
    ser_pro = models.ForeignKey(ser_pro_table, on_delete=models.CASCADE)
    LOGIN = models.ForeignKey(login_table, on_delete=models.CASCADE)
    medical_store_name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.IntegerField()
    email = models.CharField(max_length=100)
    phone = models.BigIntegerField()

class medicine_table(models.Model):
    medical_store = models.ForeignKey(medical_store_table, on_delete=models.CASCADE)
    medicine = models.CharField(max_length=100)
    image = models.FileField()
    price = models.CharField(max_length=100)
    stock = models.CharField(max_length=100)







class supermarket_table(models.Model):
    lid = models.ForeignKey(login_table, on_delete=models.CASCADE)
    ser_pro = models.ForeignKey(ser_pro_table, on_delete=models.CASCADE)

    name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.IntegerField()
    phone = models.BigIntegerField()
    email = models.CharField(max_length=100)



class med_req_table(models.Model):
    flat_occ = models.ForeignKey(flat_occ_table, on_delete=models.CASCADE)
    MEDICINE= models.ForeignKey(medicine_table , on_delete=models.CASCADE)
    quantity=models.CharField(max_length=100)
    date = models.DateField()
    status = models.CharField(max_length=100)





class chat_table(models.Model):
    frm_id=models.ForeignKey(login_table,on_delete=models.CASCADE,related_name="fid")
    to_id=models.ForeignKey(login_table,on_delete=models.CASCADE,related_name="tid")

    chat = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    time = models.CharField(max_length=100)


class  product_table(models.Model):
    supermarket = models.ForeignKey(supermarket_table, on_delete=models.CASCADE)

    product_name=models.CharField(max_length=100)
    image = models.FileField()
    price = models.CharField(max_length=100)
    stock= models.CharField(max_length=100)

class supermarket_req_table(models.Model):
    flat_occ = models.ForeignKey(flat_occ_table, on_delete=models.CASCADE)
    PRODUCT = models.ForeignKey(product_table, on_delete=models.CASCADE)
    quantity=models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    status = models.CharField(max_length=100)



class ser_req_table(models.Model):
    flat_occ= models.ForeignKey(flat_occ_table, on_delete=models.CASCADE)

    date=models.DateField()
    status=models.CharField(max_length=100)


class fac_booking(models.Model):
    fac=models.ForeignKey(facilities_table,on_delete=models.CASCADE)
    flat_occ= models.ForeignKey(flat_occ_table, on_delete=models.CASCADE)

    date = models.CharField(max_length=100)
    from_time = models.CharField(max_length=100)
    to_time = models.CharField(max_length=100)
    status = models.CharField(max_length=100)




































