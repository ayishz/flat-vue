from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
# Create your views here.
from flat.models import *

def adm_login(request):
    return render(request,"lo_index.html")

def logout(request):
    auth.logout(request)
    return render(request,"lo_index.html")

def loginpost(request):
    print (request.POST,"JJJJJJJJJJJJJJJJJJJJJ")
    uname=request.POST['textfield']
    password=request.POST['textfield2']
    try:
        ob=login_table.objects.get(username=uname,password=password)
        print(ob,"KKKKKKKKKKK")
        if ob.type=="admin":

            request.session['lid']=ob.id
            ob1 = auth.authenticate(username='admin', password='123')
            if ob1 is not None:
                auth.login(request, ob1)

            return HttpResponse('''<script>alert("welcome admin");window.location='/adm_home'</script>''')
        elif ob.type =="medicalshop":

            request.session['lid']=ob.id
            ob1 = auth.authenticate(username='admin', password='123')
            if ob1 is not None:
                auth.login(request, ob1)
            return HttpResponse('''<script>alert("welcome ");window.location='/med_shop_home'</script>''')

        elif ob.type == "Security":

            request.session['lid'] = ob.id
            return HttpResponse('''<script>alert("welcome ");window.location='/security_home'</script>''')

        elif ob.type == "ser_pro":

            request.session['lid'] = ob.id
            ob1 = auth.authenticate(username='admin', password='123')
            if ob1 is not None:
                auth.login(request, ob1)
            return HttpResponse('''<script>alert("welcome ");window.location='/service_pro_home'</script>''')

        elif ob.type == "supermarket":

            request.session['lid'] = ob.id
            ob1 = auth.authenticate(username='admin', password='123')
            if ob1 is not None:
                auth.login(request, ob1)
            return HttpResponse('''<script>alert("welcome ");window.location='/super_home'</script>''')
        else:
            return HttpResponse('''<script>alert("invalid user");window.location='/'</script>''')
    except Exception as e:
        print(e)
        return HttpResponse('''<script>window.location='/'</script>''')





@login_required(login_url='/')

def add_flat_occ(request):
    return render(request,"admin/Add_flat_occ.html")

@login_required(login_url='/')

def insert_flat_occ(request):
    n=request.POST['textfield']
    photo = request.FILES['file']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    gen=request.POST['radiobutton']
    phn=request.POST['textfield5']
    email=request.POST['textfield6']
    uname = request.POST['textfield7']
    pw = request.POST['textfield8']
    fs=FileSystemStorage()
    fsave=fs.save(photo.name,photo)

    ob1 = login_table()
    ob1.username = uname
    ob1.password = pw
    ob1.type = 'flat_occp'
    ob1.save()

    ob=flat_occ_table()
    ob.name=n
    ob.photo =fsave
    ob.place = place
    ob.post = post
    ob.pin= pin
    ob.gender= gen
    ob.phone= phn
    ob.email = email
    ob.username = uname
    ob.password = pw
    ob.lid=ob1
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/adm_home'</script>''')
@login_required(login_url='/')
def edit_flat_occv(request):
    try:
        n=request.POST['textfield']
        photo = request.FILES['file']
        place=request.POST['textfield2']
        post=request.POST['textfield3']
        pin=request.POST['textfield4']
        gen=request.POST['radiobutton']
        phn=request.POST['textfield5']
        email=request.POST['textfield6']
        fs=FileSystemStorage()
        fsave=fs.save(photo.name,photo)

        ob=flat_occ_table.objects.get(id=request.session['sid'])
        ob.name=n
        ob.photo =fsave
        ob.place = place
        ob.post = post
        ob.pin= pin
        ob.gender= gen
        ob.phone= phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_flat_occ'</script>''')
    except:
        n = request.POST['textfield']
        place = request.POST['textfield2']
        post = request.POST['textfield3']
        pin = request.POST['textfield4']
        gen = request.POST['radiobutton']
        phn = request.POST['textfield5']
        email = request.POST['textfield6']


        ob = flat_occ_table.objects.get(id=request.session['sid'])
        ob.name = n
        ob.place = place
        ob.post = post
        ob.pin = pin
        ob.gender = gen
        ob.phone = phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_flat_occ'</script>''')
@login_required(login_url='/')

def dlt_flatocc(request,id):
    ob = login_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_flat_occ'</script>''')

@login_required(login_url='/')

def add_notifictn(request):
    return render(request,"admin/add_notifictn.html")
@login_required(login_url='/')

def insert_notificatn(request):
    n=request.POST['textfield']
    ob=notn_table()
    ob.notification=n
    ob.date=datetime.today()
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/adm_home'</script>''')
@login_required(login_url='/')

def add_security(request):
    return render(request,"admin/Add_security.html")
@login_required(login_url='/')

def insert_security(request):
    fn=request.POST['textfield']
    ln= request.POST['textfield1']
    photo = request.FILES['file']
    fs = FileSystemStorage()
    fsave = fs.save(photo.name, photo)
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    gen=request.POST['radiobutton']
    phn=request.POST['textfield5']
    email=request.POST['textfield6']
    uname = request.POST['textfield7']
    pw = request.POST['textfield8']

    ob1 = login_table()
    ob1.username = uname
    ob1.password = pw
    ob1.type = 'Security'
    ob1.save()

    ob=security_table()
    ob.fname=fn
    ob.lname=ln
    ob.image =fsave
    ob.place = place
    ob.post = post
    ob.pin= pin
    ob.gender= gen
    ob.phone= phn
    ob.email = email
    ob.username = uname
    ob.password = pw
    ob.lid=ob1
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/adm_home'</script>''')
@login_required(login_url='/')

def edit_securityv(request):
    try:
        fn=request.POST['textfield']
        ln= request.POST['textfield1']
        photo = request.FILES['file']
        fs = FileSystemStorage()
        fsave = fs.save(photo.name, photo)
        place=request.POST['textfield2']
        post=request.POST['textfield3']
        pin=request.POST['textfield4']
        gen=request.POST['radiobutton']
        phn=request.POST['textfield5']
        email=request.POST['textfield6']


        ob=security_table.objects.get(id=request.session['sid'])
        ob.fname=fn
        ob.lname=ln
        ob.image =fsave
        ob.place = place
        ob.post = post
        ob.pin= pin
        ob.gender= gen
        ob.phone= phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_security'</script>''')
    except:
        fn = request.POST['textfield']
        ln = request.POST['textfield1']

        place = request.POST['textfield2']
        post = request.POST['textfield3']
        pin = request.POST['textfield4']
        gen = request.POST['radiobutton']
        phn = request.POST['textfield5']
        email = request.POST['textfield6']

        ob = security_table.objects.get(id=request.session['sid'])
        ob.fname = fn
        ob.lname = ln
        ob.place = place
        ob.post = post
        ob.pin = pin
        ob.gender = gen
        ob.phone = phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_security'</script>''')
@login_required(login_url='/')

def dlt_sec(request,id):
    ob = login_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_security'</script>''')
@login_required(login_url='/')

def add_service_pro(request):
    return render(request,"admin/Add_service_pro.html")
@login_required(login_url='/')

def insert_service_pro(request):
    fn=request.POST['textfield']
    ln = request.POST['textfield1']
    imag = request.FILES['file']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    gen=request.POST['radiobutton']
    phn=request.POST['textfield5']
    email=request.POST['textfield6']
    uname = request.POST['textfield7']
    pw = request.POST['textfield8']
    fs=FileSystemStorage()
    fsave=fs.save(imag.name,imag)

    ob1=login_table()
    ob1.username=uname
    ob1.password=pw
    ob1.type='ser_pro'
    ob1.save()

    ob=ser_pro_table()
    ob.fname=fn
    ob.lname=ln
    ob.image =fsave
    ob.place = place
    ob.post = post
    ob.pin= pin
    ob.gender= gen
    ob.phone= phn
    ob.email = email
    ob.lid=ob1
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/adm_home'</script>''')
@login_required(login_url='/')

def edit_service_prov(request):
    try:
        fn=request.POST['textfield']
        ln = request.POST['textfield1']
        imag = request.FILES['file']
        place=request.POST['textfield2']
        post=request.POST['textfield3']
        pin=request.POST['textfield4']
        gen=request.POST['radiobutton']
        phn=request.POST['textfield5']
        email=request.POST['textfield6']

        fs=FileSystemStorage()
        fsave=fs.save(imag.name,imag)

        ob=ser_pro_table.objects.get(id=request.session['sid'])
        ob.fname=fn
        ob.lname=ln
        ob.image =fsave
        ob.place = place
        ob.post = post
        ob.pin= pin
        ob.gender= gen
        ob.phone= phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_service_pro'</script>''')
    except:
        fn = request.POST['textfield']
        ln = request.POST['textfield1']
        place = request.POST['textfield2']
        post = request.POST['textfield3']
        pin = request.POST['textfield4']
        gen = request.POST['radiobutton']
        phn = request.POST['textfield5']
        email = request.POST['textfield6']


        ob = ser_pro_table.objects.get(id=request.session['sid'])
        ob.fname = fn
        ob.lname = ln
        ob.place = place
        ob.post = post
        ob.pin = pin
        ob.gender = gen
        ob.phone = phn
        ob.email = email
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_service_pro'</script>''')

@login_required(login_url='/')

def delete_ser_po(request,id):
    ob=login_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_service_pro'</script>''')
@login_required(login_url='/')

def adm_home(request):
    return render(request,"admin/admin_index.html")
@login_required(login_url='/')

def check_entryexits_info(request):
    ob=time_sch_table.objects.all()
    print(ob)
    return render(request,"admin/check_entryexits_info.html",{'val':ob})

@login_required(login_url='/')






def manage_flat_occ(request):
    ob=flat_occ_table.objects.all()
    return render(request,"admin/manage_flat_occ.html",{'val':ob})
@login_required(login_url='/')

def manage_flatocc_sch(request):
    n=request.POST['textfield']
    ob = flat_occ_table.objects.filter(name__icontains=n)
    return render(request,"admin/manage_flat_occ.html",{'val':ob})
@login_required(login_url='/')

def editflatocc(request,id):
    ob=flat_occ_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"admin/edit_flat_occ.html",{'val':ob})
@login_required(login_url='/')

def manage_notifictn(request):
    ob=notn_table.objects.all()
    return render(request,"admin/manage_notifictn.html",{'val':ob})
@login_required(login_url='/')

def manage_security(request):
    ob=security_table.objects.all()
    return render(request,"admin/manage_security.html",{'val':ob})
@login_required(login_url='/')

def manage_seurity_sch(request):
    n=request.POST['textfield']
    ob = security_table.objects.filter(fname__icontains=n)
    return render(request,"admin/manage_security.html",{'val':ob})
@login_required(login_url='/')

def editsec(request,id):
    ob=security_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"admin/editsec.html",{'val':ob})


@login_required(login_url='/')

def manage_service_pro(request):
    ob=ser_pro_table.objects.all()
    return render(request,"admin/manage_service_pro.html",{'val':ob})
@login_required(login_url='/')

def manage_ser_po_sch(request):
    n=request.POST['textfield']
    ob = ser_pro_table.objects.filter(fname__icontains=n)
    return render(request,"admin/manage_security.html",{'val':ob})
@login_required(login_url='/')

def editser_pro(request,id):
    ob=ser_pro_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"admin/edit_service_pro.html",{'val':ob})
@login_required(login_url='/')

def send_reply(request,id):
    request.session['rep_id'] = id
    ob = complaint_table.objects.get(id=id)

    return render(request,"admin/send_reply.html",{'val':ob})

@login_required(login_url='/')


def edit_reply(request):
    s = request.POST['textfield']

    ob=complaint_table.objects.get(id=request.session['rep_id'])
    ob.reply=s
    ob.save()
    return HttpResponse('''<script>alert("Edited");window.location='/view_complaint'</script>''')
@login_required(login_url='/')


def view_complaint(request):
    ob=complaint_table.objects.all()
    return render(request,"admin/view_complaint.html",{'val':ob})
@login_required(login_url='/')

def view_spot_notificatn(request):
    ob=spot_notn_table.objects.all()
    return render(request,"admin/view_spot_notificatn.html",{'val':ob})
@login_required(login_url='/')

def view_spot_sch(request):
    n=request.POST['date']
    ob=spot_notn_table.objects.filter(date=n)
    return render(request,"admin/view_spot_notificatn.html",{'val':ob})
@login_required(login_url='/')


def add_med_store(request):
    return render(request,"ser_pro/add_med_store.html")
@login_required(login_url='/')

def insert_med_store(request):
    n = request.POST['textfield']
    place = request.POST['textfield1']
    post = request.POST['textfield2']
    pin = request.POST['textfield3']
    phn = request.POST['textfield5']
    email = request.POST['textfield4']
    uname = request.POST['textfield6']
    ps = request.POST['textfield7']

    ob1 = login_table()
    ob1.username = uname
    ob1.password = ps
    ob1.type = 'medicalshop'
    ob1.save()

    ob = medical_store_table()
    ob.medical_store_name = n
    ob.place = place
    ob.post = post
    ob.pin = pin
    ob.phone = phn
    ob.email = email
    ob.username=uname
    ob.password=ps
    ob.LOGIN=ob1
    ob.ser_pro=ser_pro_table.objects.get(lid__id=request.session['lid'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_med_store'</script>''')
@login_required(login_url='/')

def edit_med_storev(request):
    n = request.POST['textfield']
    place = request.POST['textfield1']
    post = request.POST['textfield2']
    pin = request.POST['textfield3']
    phn = request.POST['textfield5']
    email = request.POST['textfield4']

    ob = medical_store_table.objects.get(id=request.session['sid'])
    ob.medical_store_name = n
    ob.place = place
    ob.post = post
    ob.pin = pin
    ob.phone = phn
    ob.email = email
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_med_store'</script>''')
@login_required(login_url='/')

def dlt_med_store(request,id):
    ob=medical_store_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_med_store'</script>''')
@login_required(login_url='/')

def manage_med_store(request):
    ob = medical_store_table.objects.filter(ser_pro__lid_id=request.session['lid'])
    return render(request,"ser_pro/maage_med_store.html",{'val':ob})
@login_required(login_url='/')

def manage_med_store_sch(request):
    n=request.POST['textfield']
    ob = medical_store_table.objects.filter(medical_store_name__icontains=n)
    return render(request,"ser_pro/maage_med_store.html",{'val':ob})
@login_required(login_url='/')

def edit_med_store(request,id):
    ob=medical_store_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"ser_pro/edit_med_store.html",{'val':ob})
@login_required(login_url='/')

def manage_fac(request):
    ob=facilities_table.objects.all()
    return render(request,"ser_pro/manage_fac.html",{'val':ob})
@login_required(login_url='/')

def manage_fac_sch(request):
    n=request.POST['textfield']
    ob = facilities_table.objects.filter(date=n)
    return render(request,"ser_pro/manage_fac.html",{'val':ob})
@login_required(login_url='/')

def edit_fac(request,id):
    ob=facilities_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"ser_pro/edit_fac.html",{'val':ob})
@login_required(login_url='/')

def send_complaint(request):
    return render(request,"ser_pro/send_comp.html")
@login_required(login_url='/')

def insert_complaint(request):
    n= request.POST['textfield']



    ob = complaint_table()
    ob.complaint=n
    ob.date=datetime.now()
    ob.reply='pending'
    ob.lid=login_table.objects.get(id=request.session['lid'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/service_pro_home'</script>''')
@login_required(login_url='/')


def send_complaintviewreply(request):
    ob=complaint_table.objects.all()
    return render(request,"ser_pro/send_complaintview_reply.html",{'val':ob})
@login_required(login_url='/')

def service_pro_home(request):
    return render(request,"ser_pro/serpo_index.html")
@login_required(login_url='/')

def add_fac(request):
    return render(request,"ser_pro/add_fac.html")
@login_required(login_url='/')

def insert_fac(request):
    n=request.POST['textfield4']
    d=request.POST['textfield1']
    a=request.POST['textfield3']
    t=request.POST['textfield5']

    ob=facilities_table()
    ob.facility=n
    ob.detail=d
    ob.name=a
    ob.type=t
    ob.date = datetime.today()
    ob.ser_pro=ser_pro_table.objects.get(lid__id=request.session['lid'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/service_pro_home'</script>''')
@login_required(login_url='/')

def edit_facv(request):
    n=request.POST['textfield4']
    d=request.POST['textfield1']
    a=request.POST['textfield3']
    t=request.POST['textfield5']



    ob=facilities_table.objects.get(id=request.session['sid'])
    ob.facility=n
    ob.detail=d
    ob.name = a
    ob.type = t
    ob.date = datetime.today()
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_fac'</script>''')
@login_required(login_url='/')


def dlt_fac(request,id):
    ob=facilities_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_fac'</script>''')

@login_required(login_url='/')




def add_superpro(request):
    return render(request,"ser_pro/add_superpro.html")
@login_required(login_url='/')

def insert_superpro(request):
    n = request.POST['textfield']
    photo = request.FILES['file']
    price = request.POST['textfield2']
    stock = request.POST['textfield3']
    fs = FileSystemStorage()
    fsave = fs.save(photo.name, photo)

    ob = product_table()
    ob.product_name = n
    ob.image = fsave
    ob.price = price
    ob.stock = stock
    ob.supermarket = supermarket_table.objects.get(id=request.session['super_id'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/service_pro_home'</script>''')
@login_required(login_url='/')

def edit_superprov(request):
    try:
        n = request.POST['textfield']
        photo = request.FILES['file']
        price = request.POST['textfield2']
        stock = request.POST['textfield3']
        fs = FileSystemStorage()
        fsave = fs.save(photo.name, photo)

        ob = product_table.objects.get(id=request.session['spid'])
        ob.product_name = n
        ob.image = fsave
        ob.price = price
        ob.stock = stock
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')
    except:
        n = request.POST['textfield']
        price = request.POST['textfield2']
        stock = request.POST['textfield3']

        ob = product_table.objects.get(id=request.session['spid'])
        ob.product_name = n
        ob.price = price
        ob.stock = stock
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')
@login_required(login_url='/')

def dlt_superpro(request,id):
    ob=product_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')
@login_required(login_url='/')

def add_pro(request):
    return render(request,"ser_pro/add_pro.html")
@login_required(login_url='/')

def insert_pro(request):
    n=request.POST['textfield']
    photo = request.FILES['file']
    price=request.POST['textfield2']
    stock=request.POST['textfield3']
    fs=FileSystemStorage()
    fsave=fs.save(photo.name,photo)

    ob=medicine_table()
    ob.medicine=n
    ob.image =fsave
    ob.price = price
    ob.stock = stock
    ob.medical_store=medical_store_table.objects.get(id=request.session['medical_s_id'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/service_pro_home'</script>''')
@login_required(login_url='/')

def edit_prov(request):
    try:
        n=request.POST['textfield']
        photo = request.FILES['file']
        price=request.POST['textfield2']
        stock=request.POST['textfield3']
        fs=FileSystemStorage()
        fsave=fs.save(photo.name,photo)

        ob=medicine_table.objects.get(id=request.session['sid'])
        ob.medicine=n
        ob.image =fsave
        ob.price = price
        ob.stock = stock
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/service_pro_home'</script>''')
    except:

        n=request.POST['textfield']
        price=request.POST['textfield2']
        stock=request.POST['textfield3']

        ob=medicine_table.objects.get(id=request.session['sid'])
        ob.medicine=n
        ob.price = price
        ob.stock = stock
        ob.save()
        return HttpResponse('''<script>alert("inserted");window.location='/manage_pro'</script>''')
@login_required(login_url='/')

def dlt_pro(request,id):
    ob=medicine_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_med_store'</script>''')
@login_required(login_url='/')


def add_supermarket(request):
    return render(request,"ser_pro/add_supermarket.html")
@login_required(login_url='/')

def insert_super(request):
    n = request.POST['textfield']
    place = request.POST['textfield1']
    post = request.POST['textfield2']
    pin = request.POST['textfield3']
    phn = request.POST['textfield5']
    email = request.POST['textfield4']
    uname = request.POST['textfield6']
    ps = request.POST['textfield7']

    ob1=login_table()
    ob1.username=uname
    ob1.password=ps
    ob1.type='supermarket'
    ob1.save()

    ob = supermarket_table()
    ob.lid=ob1
    ob.name = n
    ob.place = place
    ob.post = post
    ob.pin = pin
    ob.phone = phn
    ob.email = email
    ob.uname = uname
    ob.ps =ps
    ob.ser_pro=ser_pro_table.objects.get(lid__id=request.session['lid'])
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')
@login_required(login_url='/')

def edit_superv(request):
    n = request.POST['textfield']
    place = request.POST['textfield1']
    post = request.POST['textfield2']
    pin = request.POST['textfield3']
    phn = request.POST['textfield5']
    email = request.POST['textfield4']



    ob = supermarket_table.objects.get(id=request.session['sid'])
    ob.name = n
    ob.place = place
    ob.post = post
    ob.pin = pin
    ob.phone = phn
    ob.email = email
    ob.save()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')
@login_required(login_url='/')

def dlt_super(request,id):
    ob=supermarket_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("inserted");window.location='/manage_super_market'</script>''')

@login_required(login_url='/')




def manage_pro(request,id):
    ob = medicine_table.objects.filter(medical_store__id=id)
    request.session['medical_s_id']=id
    return render(request,"ser_pro/manage_pro.html",{'val':ob})
@login_required(login_url='/')

def manage_pro_sch(request):
    n=request.POST['textfield']
    ob = medicine_table.objects.filter(medicine__icontains=n,medical_store=request.session['medical_s_id'])
    return render(request,"ser_pro/manage_pro.html",{'val':ob})
@login_required(login_url='/')

def edit_pro(request,id):
    ob=medicine_table.objects.get(id=id)
    request.session['ppid']=id
    return render(request,"ser_pro/edit_pro.html",{'val':ob})
@login_required(login_url='/')

def manage_superpro(request,id):
    ob=product_table.objects.filter(supermarket__id=id)
    request.session['super_id']=id
    return render(request,"ser_pro/manage_superpro.html",{'val':ob})
@login_required(login_url='/')

def manage_superpro_sch(request):
    n=request.POST['textfield']
    ob = product_table.objects.filter(product_name__icontains=n,supermarket=request.session['super_id'])
    return render(request,"ser_pro/manage_superpro.html",{'val':ob})
@login_required(login_url='/')

def edit_superpro(request,id):
    ob=product_table.objects.get(id=id)
    request.session['spid']=id
    return render(request,"ser_pro/edit_superpro.html",{'val':ob})
@login_required(login_url='/')

def manage_super_market(request):
    ob = supermarket_table.objects.all()
    return render(request,"ser_pro/manage_super_market.html",{'val':ob})
@login_required(login_url='/')

def manage_super_market_sch(request):
    n=request.POST['textfield']
    ob = supermarket_table.objects.filter(name__icontains=n)
    return render(request,"ser_pro/manage_super_market.html",{'val':ob})

@login_required(login_url='/')

def edit_sumarket(request,id):
    ob=supermarket_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"ser_pro/edit_supermarket.html",{'val':ob})
@login_required(login_url='/')


def view_req_and_update_stat(request):
    ob=ser_req_table.objects.all()
    return render(request,"ser_pro/view_req_and_update_stat.html",{'val':ob})
@login_required(login_url='/')

def req_accept(request,id):

    ob=med_req_table.objects.get(id=id)
    ob.status='accept'
    ob.save()
    return HttpResponse('''<script>alert("Accepted");window.location='/view_req_and_update_stat'</script>''')
@login_required(login_url='/')

def req_reject(request,id):
    ob=med_req_table.objects.get(id=id)
    ob.status='reject'
    ob.save()
    return HttpResponse('''<script>alert("Rejected");window.location='/view_req_and_update_stat'</script>''')

# supermarket
@login_required(login_url='/')

def reqs_accept(request,id):

    ob=supermarket_req_table.objects.get(id=id)
    ob.status='accept'
    ob.save()
    return HttpResponse('''<script>alert("Accepted");window.location='/view_req_and_update_stat'</script>''')

@login_required(login_url='/')


def reqs_reject(request,id):
    ob=supermarket_req_table.objects.get(id=id)
    ob.status='reject'
    ob.save()
    return HttpResponse('''<script>alert("Rejected");window.location='/view_req_and_update_stat'</script>''')

@login_required(login_url='/')


def update_sch(request):
    type=request.POST['select']
    print(type,"RRRRRRRRRRRRRRRRRRRR")
    if type == 'supermarket':
        ob1 = supermarket_req_table.objects.filter(PRODUCT__supermarket__ser_pro__lid__id=request.session['lid'])
        return render(request, "ser_pro/view_req_and_update_stat.html", {'val1': ob1 ,'type':type})
    else:
        ob2 = med_req_table.objects.filter(MEDICINE__medical_store__ser_pro__lid__id=request.session['lid'])
        print(ob2,"DDDDDDDDDDDDDDDDDDDDDDDDD")
        return render(request, "ser_pro/view_req_and_update_stat.html", {'val2': ob2,'type':type})







@login_required(login_url='/')


def super_home(request):
    return render(request,"supermarket/sup_index.html")
@login_required(login_url='/')

def update_stock2(request,id):
    request.session['sup_id'] = id
    ob = product_table.objects.get(id=id)
    return render(request,"supermarket/upadte2_stock.html",{'val':ob})
@login_required(login_url='/')

def edit_supstock(request):
    s = request.POST['textfield']

    ob = product_table.objects.get(id=request.session['sup_id'])
    ob.stock = s
    ob.save()
    return HttpResponse('''<script>alert("Edited");window.location='/update_stock_s'</script>''')
@login_required(login_url='/')


def edit_super_sch(request):
    n=request.POST['select']
    ob=product_table.objects.filter(id=n)
    return render(request,"supermarket/update_stock.html",{'val':ob})
@login_required(login_url='/')


def update_stock_s(request):
    ob = product_table.objects.filter(supermarket__lid__id=request.session['lid'])
    return render(request,"supermarket/update_stock.html",{'val': ob})
@login_required(login_url='/')

def edit_supup(request,id):
    ob=product_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"supermarket/update_stock.html",{'val':ob})
@login_required(login_url='/')

def view_order(request):
    ob = supermarket_req_table.objects.filter(PRODUCT__supermarket__lid__id=request.session['lid'])
    return render(request,"supermarket/view_ordr.html",{'val':ob})
@login_required(login_url='/')


def view_super_sch(request):
    n=request.POST['date']
    ob=supermarket_req_table.objects.filter(date=n)
    return render(request,"supermarket/update_stock.html",{'val':ob})

@login_required(login_url='/')




def med_shop_home(request):
    return  render(request,"medicalshop/med_index.html")
@login_required(login_url='/')

def update_stock4(request,id):
    request.session['Med_id'] = id
    ob = medicine_table.objects.get(id=id)
    return  render(request,"medicalshop/upadte_stock.html",{'val':ob})
@login_required(login_url='/')

def edit_medstock(request):
    s=request.POST['textfield']

    ob=medicine_table.objects.get(id=request.session['Med_id'])
    ob.stock=s
    ob.save()
    return HttpResponse('''<script>alert("Edited");window.location='/updste_stock3'</script>''')
@login_required(login_url='/')

def edit_med_sch(request):
    n=request.POST['select']
    ob=medicine_table.objects.filter(id=n)
    return render(request,"medicalshop/update_stock.html",{'val':ob})

@login_required(login_url='/')

def updste_stock3(request):
    ob = medicine_table.objects.filter(medical_store__LOGIN__id=request.session['lid'])
    return  render(request,"medicalshop/update_stock.html",{'val':ob})
@login_required(login_url='/')

def edit_medup(request,id):
    ob=medicine_table.objects.get(id=id)
    request.session['sid']=id
    return render(request,"medicalshop/update_stock.html",{'val':ob})
@login_required(login_url='/')

def view_ordr(request):
    ob = med_req_table.objects.filter(MEDICINE__medical_store__LOGIN__id=request.session['lid'])
    return render(request,"medicalshop/view_ordr.html",{'val':ob})
@login_required(login_url='/')

def view_med_sch(request):
    n=request.POST['date']
    ob=med_req_table.objects.filter(date=n)
    return render(request,"supermarket/view_ordr.html",{'val':ob})










# -------------------------------------------------------------------------



import json
from django.http import JsonResponse


def logincode(request):
    print(request.POST)
    un = request.POST['uname']
    pwd = request.POST['pswd']
    print(un, pwd)
    try:
        users = login_table.objects.get(username=un, password=pwd)

        if users is None:
            data = {"task": "invalid"}
        else:
            print("in user function")
            data = {"task": "valid", "id": users.id,'type':users.type}
        r = json.dumps(data)
        print(r)
        return HttpResponse(r)
    except:
        data = {"task": "invalid"}
        r = json.dumps(data)
        print(r)
        return HttpResponse(r)

def addtimesch(request):
        lid=request.POST['lid']
        visitor_name = request.POST['visitor_name']
        no_of_member = request.POST['no_of_member']
        from_time = request.POST['from_time']
        to_time = request.POST['to_time']
        date = request.POST['date']
        ob=time_sch_table()
        ob.visitor_name = visitor_name
        ob.no_of_member = no_of_member
        ob.from_time = from_time
        ob.to_time = to_time
        ob.date = date
        ob.status='pending'
        ob.flat_occ=flat_occ_table.objects.get(lid__id=lid)
        ob.save()

        data = {"task": "valid"}
        r = json.dumps(data)

        print(r)
        return HttpResponse(r)


def sendcomp(request):
        lid = request.POST['lid']
        complaint = request.POST['complaint']
        lob = complaint_table()
        lob.complaint = complaint
        lob.date = datetime.today()
        lob.reply = 'pending'
        lob.lid = login_table.objects.get(id=lid)
        lob.save()
        data = {"task": "valid"}
        r = json.dumps(data)
        print(r)
        return HttpResponse(r)

def viewreply(request):
    lid = request.POST['lid']
    ob=complaint_table.objects.filter(lid__id=lid)
    mdata=[]
    for i in ob:
        data={'complaint':i.complaint,'reply':i.reply,'date':str(i.date)}
        mdata.append(data)
        print(mdata)
    r=json.dumps(mdata)
    return HttpResponse(r)

def view_profrm_med(request):

    ob = medicine_table.objects.all()

    mdata = []
    for i in ob:
        data = {'medicine': i.medicine, 'price': i.price,'stock': i.stock}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)


def view_profrm_sup(request):

    ob = product_table.objects.all()

    mdata = []
    for i in ob:
        data = {'fid':i.id,'pro_name': i.product_name, 'price': i.price,'stock': i.stock}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)




def view_req_ser(request):
    lid = request.POST['lid']

    ob = ser_req_table.objects.filter(flat_occ__lid__id=lid)

    mdata = []
    for i in ob:
        data = {'name': i.flat_occ.name, 'Address': i.flat_occ.place.post.pin, 'phone': i.flat_occ.phone,'email':i.flat_occ.email}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)


def send_req_med(request):
    lid = request.POST['lid']
    fid=request.POST['fid']
    quantity = request.POST['quantity']

    ob = med_req_table()
    ob.quantity = quantity
    ob.date = datetime.today()
    ob.status = 'pending'
    ob.flat_occ = flat_occ_table.objects.get(lid=lid)
    ob.MEDICINE = medicine_table.objects.get(id=fid)
    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)

def send_req_sup(request):
    lid = request.POST['lid']
    fid=request.POST['fid']
    quantity=request.POST['quantity']
    ob=supermarket_req_table()
    ob.quantity=quantity
    ob.date=datetime.today()
    ob.status ='pending'
    ob.flat_occ = flat_occ_table.objects.get(lid=lid)
    ob.PRODUCT=product_table.objects.get(id=fid)
    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)


def view_ser(request):
    ob = facilities_table.objects.all()

    mdata = []
    for i in ob:
        data = {'fid':i.id,'facility': i.facility, 'detail': i.detail, 'date': str(i.date),'type':i.type,'name':i.name}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)

def allow_visitor(request):
    ob=time_sch_table.objects.all()
    mdata=[]
    for i in ob:
        data = {'name':i.flat_occ.name,'fid':i.id,'date':str(i.date),'from_time':i.from_time,'to_time':i.to_time,'visitor_name':i.visitor_name,'no_of_member':i.no_of_member}
        mdata.append(data)
        print(mdata)
    r = json.dumps(mdata)
    return HttpResponse(r)


def send_req(request):
    lid = request.POST['lid']
    fid=request.POST['fid']
    date=request.POST['date']
    from_time=request.POST['from_time']
    to_time=request.POST['to_time']

    ob = fac_booking()
    ob.from_time = from_time
    ob.to_time = to_time
    ob.date=date
    ob.status='pending'
    ob.flat_occ = flat_occ_table.objects.get(lid=lid)
    ob.fac=facilities_table.objects.get(id=fid)

    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)


def mngtimesch(request):
    ob=time_sch_table.objects.all()
    mdata = []
    for i in ob:
        data = {'date': i.date, 'from_time': i.from_time, 'to_time': i.to_time, 'visitor_name': i.visitor_name, 'no_of_member': i.no_of_member,'status':i.status}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)


def view_notn(request):
    ob=notn_table.objects.all()
    mdata=[]
    for i in ob:
        data={'notn':i.notification,'date':str(i.date)}
        mdata.append(data)
    r=json.dumps(mdata)
    return HttpResponse(r)

def sec_home(request):
    return HttpResponse()

def sec_view_notn(request):
    # lid = request.POST['lid']
    ob = spot_notn_table.objects.all()

    mdata = []
    for i in ob:
        data = {'notn': i.notification, 'date':str(i.date)}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)


def view_req_sta(request):
    # lid=request.POST['lid']
    ob=fac_booking.objects.all()
    mdata = []
    for i in ob:
        data = {'status':i.status,'fid': i.id, 'name': i.fac.name, 'date': str(i.date)}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)

def chat_with_sec(request):
    ob=security_table.objects.all()
    mdata=[]
    for i in ob:
        data = {'id': i.lid.id, 'fname': i.fname, 'lname': i.lname}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)




def chat_with_usr(request):
    ob=flat_occ_table.objects.all()
    mdata=[]
    for i in ob:
        data = {'id': i.lid.id, 'name': i.name}
        mdata.append(data)
    r = json.dumps(mdata)
    return HttpResponse(r)

def view_message2(request):
    print(request.POST)
    fromid=request.POST['fid']
    toid=request.POST['toid']
    mid=request.POST['lastmsgid']
    # print(mid,"uuuuuuuuuuuu0")
    ob=chat_table.objects.filter(Q(to_id__id=toid,frm_id__id=fromid,id__gt=mid)|Q(to_id=fromid,frm_id=toid,id__gt=mid)).order_by('id')
    # print(ob,"YYYYYYYYYYYYYYYYYYYYYYYYYYYYYY")
    data=[]
    print("++++++++==============================")
    print("++++++++==============================")
    print("++++++++==============================")
    for i in ob:
        r={"msgid":i.id,"date":i.date,"message":i.chat,"fromid":i.frm_id.id}
        data.append(r)
        print(r)
    # print(data,"JJJJJJJJJJJJJJJJJJJJJJJJJ")
    print(len(data),"=========================================")
    if len(data)>0:
        return JsonResponse({"status":"ok","res1":data})
    else:
        return JsonResponse({"status": "na"})
def in_message2(request):
    fromid = request.POST['fid']
    toid=request.POST['toid']
    chat = request.POST['msg']

    ob = chat_table()
    ob.chat = chat
    ob.time = datetime.now().strftime("%H:%M:%S")
    ob.date = datetime.now()

    ob.frm_id = login_table.objects.get(id=fromid)
    ob.to_id = login_table.objects.get(id=toid)
    ob.save()
    data = {"status": "send"}
    r = json.dumps(data)

    print(r)
    return HttpResponse(r)

def add_user_notn(request):
    lid=request.POST['lid']
    notn=request.POST['notn']

    ob = spot_notn_table()
    ob.notification = notn
    ob.date = datetime.today()
    ob.lid=login_table.objects.get(id=lid)
    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)

def view_spot_notn(request):
    ob=spot_notn_table.objects.all()
    mdata=[]
    for i in ob:
        data={'notn':i.notification,'date':str(i.date)}
        mdata.append(data)
    r=json.dumps(mdata)
    return HttpResponse(r)



def upd_tym_acc(request):
    id=request.POST['tid']

    ob = time_sch_table.objects.get(id=id)
    ob.status = 'Accepted'

    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)


def upd_tym_rej(request):
    id = request.POST['tid']

    ob = time_sch_table.objects.get(id=id)
    ob.status = 'Rejected'

    ob.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    print(r)
    return HttpResponse(r)


























