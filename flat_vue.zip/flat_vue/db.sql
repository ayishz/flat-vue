/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 8.0.33 : Database - flat
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`flat` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `flat`;

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_permission` */

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user` */

insert  into `auth_user`(`id`,`password`,`last_login`,`is_superuser`,`username`,`first_name`,`last_name`,`email`,`is_staff`,`is_active`,`date_joined`) values 
(1,'pbkdf2_sha256$260000$VMiMhHcm7h2OiTqFTfpB73$Adv2oCKLVJuqcsyzMnJhU8IP82zmTPgHU0P3M112ACk=','2023-10-25 07:07:42.250320',1,'admin','','','admin@gmail.com',1,1,'2023-10-20 11:57:39.337544');

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_content_type` */

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_migrations` */

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('2dsotfy4kzeihqpulfmhk0953kvzctsn','.eJxVjkEOwiAURO_C2hD6AQGX7j0D4cPHVpvWlLIy3t2SsOn2zczLfNk8JXazF-ZD3UdfC22-ETawE8MQ37S0IL3C8lx5XJd9m5C3Cu9p4Y810Xzv3ZNgDGU81jkOVjhEkyzYqBClG6QC6XLIiMpeUUhDoAlIYLJCRm0EkCYKIGI2h7TUTz8Jvz9v1z54:1qvXzS:WRE8T_3zCIVrbNF6L4OyHeXgOBrgDVIoX-mq6BUiJJE','2023-11-08 07:07:42.256339'),
('i1n88m73v6h9iifxm5uftw8x1pkfkazs','eyJsaWQiOjF9:1qnYTb:YC_sZn_zjshimxrZjgNiH3R5aP6iJsWQ2dlIoL3oiBc','2023-10-17 06:01:47.312815'),
('q9bi4h9dvf9n7vrvdzatp1zzz1tklrjv','.eJyrVsrJTFGyMtRRKgbRRjpKuakpmcmJOfHF8VCJggKYitKC1KJ4qLJiJFGYSt_UFBizKBUialQLAMH7Hbo:1qnJi5:gwBEXMT545PyMwgzqLpzDyRfA6rqsLd0EkmzBZPbb4I','2023-10-16 14:15:45.567694'),
('twfjc05scni38ix5aeygmcw6p7fk7hzg','.eJxVjDsOwyAQBe9CHSE-JkDK9DkDYpclOLFAMnYV5e4Jkhu3M_Pehy1zYjd5YSHuWwl7pzUMwiQ7MYj4pjpEesX6bBxb3dYZ-Ej4YTt_tETL_WhPByX28l9nlE54AJuccjgBaC_1pLTPMQNM7gpCW1KGFAlITmg0VigyRFEJzJZ9f1lbOjo:1qvXoS:l9UZ2bwEU5DdzHBeOUlCcmURyQNgzO4LQn4YmkeqXM0','2023-11-08 06:56:20.026106'),
('v50yo1n00azspq22p35q91mrbdh5pccc','eyJsaWQiOjEsInNpZCI6MX0:1qncYU:4N3o2vtnpAMX9y97QujErxLfRWkwxRbQP53I2qrsFP4','2023-10-17 10:23:06.096837');

/*Table structure for table `flat_chat_table` */

DROP TABLE IF EXISTS `flat_chat_table`;

CREATE TABLE `flat_chat_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chat` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `frm_id_id` bigint NOT NULL,
  `to_id_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_chat_table_frm_id_id_9171dc1d_fk_flat_login_table_id` (`frm_id_id`),
  KEY `flat_chat_table_to_id_id_d7285552_fk_flat_login_table_id` (`to_id_id`),
  CONSTRAINT `flat_chat_table_frm_id_id_9171dc1d_fk_flat_login_table_id` FOREIGN KEY (`frm_id_id`) REFERENCES `flat_login_table` (`id`),
  CONSTRAINT `flat_chat_table_to_id_id_d7285552_fk_flat_login_table_id` FOREIGN KEY (`to_id_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_chat_table` */

insert  into `flat_chat_table`(`id`,`chat`,`date`,`time`,`frm_id_id`,`to_id_id`) values 
(1,'hi','2023-09-27 14:38:26.969856','14:38:26',3,3),
(2,'hi','2023-09-27 16:22:19.883469','16:22:19',3,2),
(3,'ttt','2023-09-27 17:17:03.501830','17:17:03',2,3),
(4,'','2023-09-27 17:17:41.530801','17:17:41',2,3),
(5,'fee','2023-09-27 17:20:36.760831','17:20:36',2,3),
(6,'','2023-09-27 17:20:37.183349','17:20:37',2,3),
(7,'fff','2023-10-03 10:21:59.255144','10:21:59',3,2),
(8,'hh','2023-10-03 10:26:54.688199','10:26:54',3,2),
(9,'hhhhhh','2023-10-03','10:26:59',2,3),
(10,'hai','2023-10-03 10:28:09.144816','10:28:09',3,2),
(11,'ff','2023-10-03 10:32:23.938008','10:32:23',3,2),
(12,'hh','2023-10-03 10:40:18.825278','10:40:18',3,2),
(13,'hhh','2023-10-03 10:40:29.211474','10:40:29',3,2),
(14,'tyu','2023-10-03 10:40:37.836425','10:40:37',3,2),
(15,'xxx','2023-10-03 10:40:37.836425','10:41:37',2,3),
(16,'hh','2023-10-03 10:41:33.037939','10:41:33',3,2),
(17,'ggg','2023-10-03','10:42:33',2,3),
(18,'hai','2023-10-03 11:09:01.191530','11:09:01',3,2),
(19,'dooo','2023-10-03 ','11:10:54',2,3);

/*Table structure for table `flat_complaint_table` */

DROP TABLE IF EXISTS `flat_complaint_table`;

CREATE TABLE `flat_complaint_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `complaint` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `lid_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_complaint_table_lid_id_d9e42001_fk_flat_login_table_id` (`lid_id`),
  CONSTRAINT `flat_complaint_table_lid_id_d9e42001_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_complaint_table` */

insert  into `flat_complaint_table`(`id`,`complaint`,`reply`,`date`,`lid_id`) values 
(2,'user should be careful with the product','okay','2023-09-27',4),
(3,'please accept our request','pending','2023-09-27',2);

/*Table structure for table `flat_fac_booking` */

DROP TABLE IF EXISTS `flat_fac_booking`;

CREATE TABLE `flat_fac_booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `from_time` varchar(100) NOT NULL,
  `to_time` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `fac_id` bigint NOT NULL,
  `flat_occ_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_fac_booking_fac_id_e28eec58_fk_flat_facilities_table_id` (`fac_id`),
  KEY `flat_fac_booking_flat_occ_id_2606dca1_fk_flat_flat_occ_table_id` (`flat_occ_id`),
  CONSTRAINT `flat_fac_booking_fac_id_e28eec58_fk_flat_facilities_table_id` FOREIGN KEY (`fac_id`) REFERENCES `flat_facilities_table` (`id`),
  CONSTRAINT `flat_fac_booking_flat_occ_id_2606dca1_fk_flat_flat_occ_table_id` FOREIGN KEY (`flat_occ_id`) REFERENCES `flat_flat_occ_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_fac_booking` */

insert  into `flat_fac_booking`(`id`,`date`,`from_time`,`to_time`,`status`,`fac_id`,`flat_occ_id`) values 
(1,'27-09-2023','4:00','5:00','pending',1,1);

/*Table structure for table `flat_facilities_table` */

DROP TABLE IF EXISTS `flat_facilities_table`;

CREATE TABLE `flat_facilities_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `facility` varchar(100) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ser_pro_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_facilities_tabl_ser_pro_id_955a9e60_fk_flat_ser_` (`ser_pro_id`),
  CONSTRAINT `flat_facilities_tabl_ser_pro_id_955a9e60_fk_flat_ser_` FOREIGN KEY (`ser_pro_id`) REFERENCES `flat_ser_pro_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_facilities_table` */

insert  into `flat_facilities_table`(`id`,`facility`,`detail`,`date`,`type`,`name`,`ser_pro_id`) values 
(1,'Trainer will be there','From indoor stadium','2023-09-27','Dance','Arjun',1),
(2,'Dj party','from stadium','2023-09-27','party','conic',1);

/*Table structure for table `flat_flat_occ_table` */

DROP TABLE IF EXISTS `flat_flat_occ_table`;

CREATE TABLE `flat_flat_occ_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` int NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` bigint NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `lid_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_flat_occ_table_lid_id_f7678a4c_fk_flat_login_table_id` (`lid_id`),
  CONSTRAINT `flat_flat_occ_table_lid_id_f7678a4c_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_flat_occ_table` */

insert  into `flat_flat_occ_table`(`id`,`name`,`place`,`post`,`pin`,`gender`,`phone`,`email`,`photo`,`lid_id`) values 
(1,'Zahara','Balusseri','balusseri',678543,'female',7558881188,'zara@gmail.com','abc_OgLQ3AM.png',2),
(2,'Ayisha safa MK','cvv','vcvcv',123456,'female',8281751469,'ayishz786@gmail.com','Screenshot (1)_qinkGNT.png',9);

/*Table structure for table `flat_login_table` */

DROP TABLE IF EXISTS `flat_login_table`;

CREATE TABLE `flat_login_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_login_table` */

insert  into `flat_login_table`(`id`,`username`,`password`,`type`) values 
(1,'admin','123','admin'),
(2,'user','123','flat_occp'),
(3,'sec','123','Security'),
(4,'ser_po','123','ser_pro'),
(5,'medcare','123','medicalshop'),
(6,'medi','123','medicalshop'),
(8,'super','123','supermarket'),
(9,'123Abc','123@Abc','flat_occp'),
(10,'sec','123','Security');

/*Table structure for table `flat_med_req_table` */

DROP TABLE IF EXISTS `flat_med_req_table`;

CREATE TABLE `flat_med_req_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `MEDICINE_id` bigint NOT NULL,
  `flat_occ_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_med_req_table_MEDICINE_id_2ae99d6c_fk_flat_medi` (`MEDICINE_id`),
  KEY `flat_med_req_table_flat_occ_id_dce1164f_fk_flat_flat` (`flat_occ_id`),
  CONSTRAINT `flat_med_req_table_flat_occ_id_dce1164f_fk_flat_flat` FOREIGN KEY (`flat_occ_id`) REFERENCES `flat_flat_occ_table` (`id`),
  CONSTRAINT `flat_med_req_table_MEDICINE_id_2ae99d6c_fk_flat_medi` FOREIGN KEY (`MEDICINE_id`) REFERENCES `flat_medicine_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_med_req_table` */

insert  into `flat_med_req_table`(`id`,`quantity`,`date`,`status`,`MEDICINE_id`,`flat_occ_id`) values 
(1,'2','2023-09-27','accept',1,1);

/*Table structure for table `flat_medical_store_table` */

DROP TABLE IF EXISTS `flat_medical_store_table`;

CREATE TABLE `flat_medical_store_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `medical_store_name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` int NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint NOT NULL,
  `LOGIN_id` bigint NOT NULL,
  `ser_pro_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_medical_store_t_ser_pro_id_9d57ba2f_fk_flat_ser_` (`ser_pro_id`),
  KEY `flat_medical_store_t_LOGIN_id_f4a6eb93_fk_flat_logi` (`LOGIN_id`),
  CONSTRAINT `flat_medical_store_t_LOGIN_id_f4a6eb93_fk_flat_logi` FOREIGN KEY (`LOGIN_id`) REFERENCES `flat_login_table` (`id`),
  CONSTRAINT `flat_medical_store_t_ser_pro_id_9d57ba2f_fk_flat_ser_` FOREIGN KEY (`ser_pro_id`) REFERENCES `flat_ser_pro_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_medical_store_table` */

insert  into `flat_medical_store_table`(`id`,`medical_store_name`,`place`,`post`,`pin`,`email`,`phone`,`LOGIN_id`,`ser_pro_id`) values 
(1,'Amyra','Kochi','Kochi',675432,'ami@gmail.com',7034567865,5,1),
(2,'Amina','Kochi','kochi',675432,'amii@gmail.com',7865435678,6,1);

/*Table structure for table `flat_medicine_table` */

DROP TABLE IF EXISTS `flat_medicine_table`;

CREATE TABLE `flat_medicine_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `medicine` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `stock` varchar(100) NOT NULL,
  `medical_store_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_medicine_table_medical_store_id_3be50b7c_fk_flat_medi` (`medical_store_id`),
  CONSTRAINT `flat_medicine_table_medical_store_id_3be50b7c_fk_flat_medi` FOREIGN KEY (`medical_store_id`) REFERENCES `flat_medical_store_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_medicine_table` */

insert  into `flat_medicine_table`(`id`,`medicine`,`image`,`price`,`stock`,`medical_store_id`) values 
(1,'Dolo','abc_IJJU6Kf.png','20','190',1);

/*Table structure for table `flat_notn_table` */

DROP TABLE IF EXISTS `flat_notn_table`;

CREATE TABLE `flat_notn_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notification` longtext NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_notn_table` */

insert  into `flat_notn_table`(`id`,`notification`,`date`) values 
(1,'Dont use the outside tap','2023-09-27');

/*Table structure for table `flat_product_table` */

DROP TABLE IF EXISTS `flat_product_table`;

CREATE TABLE `flat_product_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `stock` varchar(100) NOT NULL,
  `supermarket_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_product_table_supermarket_id_ba26c567_fk_flat_supe` (`supermarket_id`),
  CONSTRAINT `flat_product_table_supermarket_id_ba26c567_fk_flat_supe` FOREIGN KEY (`supermarket_id`) REFERENCES `flat_supermarket_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_product_table` */

insert  into `flat_product_table`(`id`,`product_name`,`image`,`price`,`stock`,`supermarket_id`) values 
(1,'icecream','Screenshot (1).png','40','60',2);

/*Table structure for table `flat_security_table` */

DROP TABLE IF EXISTS `flat_security_table`;

CREATE TABLE `flat_security_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `gender` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` int NOT NULL,
  `phone` bigint NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `lid_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_security_table_lid_id_da7288d9_fk_flat_login_table_id` (`lid_id`),
  CONSTRAINT `flat_security_table_lid_id_da7288d9_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_security_table` */

insert  into `flat_security_table`(`id`,`gender`,`fname`,`lname`,`place`,`post`,`pin`,`phone`,`email`,`image`,`lid_id`) values 
(1,'male','Fahad','abdulla','kozhikode ',' pottamal',673007,9847651469,'fahad@gmail.com','Screenshot (1)_3dmlbp0.png',3),
(2,'male','fahad','Abdulla','kozhikode','kottuli',658745,8945763245,'fah@gmail.com','abc_5bvyEl4.png',10);

/*Table structure for table `flat_ser_pro_table` */

DROP TABLE IF EXISTS `flat_ser_pro_table`;

CREATE TABLE `flat_ser_pro_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` int NOT NULL,
  `phone` bigint NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `lid_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_ser_pro_table_lid_id_bb6888c3_fk_flat_login_table_id` (`lid_id`),
  CONSTRAINT `flat_ser_pro_table_lid_id_bb6888c3_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_ser_pro_table` */

insert  into `flat_ser_pro_table`(`id`,`fname`,`lname`,`place`,`post`,`pin`,`phone`,`email`,`image`,`gender`,`lid_id`) values 
(1,'Amina','Shada','kozhikode','kommeri',673007,8281916794,'ami@gmail.com','abc_XyLHtG1.png','female',4);

/*Table structure for table `flat_ser_req_table` */

DROP TABLE IF EXISTS `flat_ser_req_table`;

CREATE TABLE `flat_ser_req_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `flat_occ_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_ser_req_table_flat_occ_id_bfd97262_fk_flat_flat` (`flat_occ_id`),
  CONSTRAINT `flat_ser_req_table_flat_occ_id_bfd97262_fk_flat_flat` FOREIGN KEY (`flat_occ_id`) REFERENCES `flat_flat_occ_table` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_ser_req_table` */

/*Table structure for table `flat_spot_notn_table` */

DROP TABLE IF EXISTS `flat_spot_notn_table`;

CREATE TABLE `flat_spot_notn_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notification` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `lid_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_spot_notn_table_lid_id_b7b37d23_fk_flat_login_table_id` (`lid_id`),
  CONSTRAINT `flat_spot_notn_table_lid_id_b7b37d23_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_spot_notn_table` */

insert  into `flat_spot_notn_table`(`id`,`notification`,`date`,`lid_id`) values 
(1,'Robber','2023-09-27',2),
(2,'Robber','2023-09-27',2),
(3,'Robber','2023-09-27',2);

/*Table structure for table `flat_supermarket_req_table` */

DROP TABLE IF EXISTS `flat_supermarket_req_table`;

CREATE TABLE `flat_supermarket_req_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `PRODUCT_id` bigint NOT NULL,
  `flat_occ_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_supermarket_req_PRODUCT_id_71a05c15_fk_flat_prod` (`PRODUCT_id`),
  KEY `flat_supermarket_req_flat_occ_id_b32b561a_fk_flat_flat` (`flat_occ_id`),
  CONSTRAINT `flat_supermarket_req_flat_occ_id_b32b561a_fk_flat_flat` FOREIGN KEY (`flat_occ_id`) REFERENCES `flat_flat_occ_table` (`id`),
  CONSTRAINT `flat_supermarket_req_PRODUCT_id_71a05c15_fk_flat_prod` FOREIGN KEY (`PRODUCT_id`) REFERENCES `flat_product_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_supermarket_req_table` */

insert  into `flat_supermarket_req_table`(`id`,`quantity`,`date`,`status`,`PRODUCT_id`,`flat_occ_id`) values 
(1,'5','2023-09-27 13:15:42.338589','accept',1,1),
(2,'9','2023-10-21 16:51:15.453372','pending',1,1),
(3,'9','2023-10-21 16:51:17.544544','pending',1,1),
(4,'9','2023-10-21 16:51:18.909354','pending',1,1),
(5,'7','2023-10-25 12:04:56.679348','pending',1,1);

/*Table structure for table `flat_supermarket_table` */

DROP TABLE IF EXISTS `flat_supermarket_table`;

CREATE TABLE `flat_supermarket_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` int NOT NULL,
  `phone` bigint NOT NULL,
  `email` varchar(100) NOT NULL,
  `lid_id` bigint NOT NULL,
  `ser_pro_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_supermarket_table_lid_id_8c5c1e71_fk_flat_login_table_id` (`lid_id`),
  KEY `flat_supermarket_tab_ser_pro_id_23ee02e7_fk_flat_ser_` (`ser_pro_id`),
  CONSTRAINT `flat_supermarket_tab_ser_pro_id_23ee02e7_fk_flat_ser_` FOREIGN KEY (`ser_pro_id`) REFERENCES `flat_ser_pro_table` (`id`),
  CONSTRAINT `flat_supermarket_table_lid_id_8c5c1e71_fk_flat_login_table_id` FOREIGN KEY (`lid_id`) REFERENCES `flat_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_supermarket_table` */

insert  into `flat_supermarket_table`(`id`,`name`,`place`,`post`,`pin`,`phone`,`email`,`lid_id`,`ser_pro_id`) values 
(2,'Malabar','kozhikode','kozhikode',675432,7865436789,'mala@gmail.com',8,1);

/*Table structure for table `flat_time_sch_table` */

DROP TABLE IF EXISTS `flat_time_sch_table`;

CREATE TABLE `flat_time_sch_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `from_time` varchar(100) NOT NULL,
  `to_time` varchar(100) NOT NULL,
  `visitor_name` varchar(100) NOT NULL,
  `no_of_member` int NOT NULL,
  `status` varchar(100) NOT NULL,
  `flat_occ_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flat_time_sch_table_flat_occ_id_4eb2dc14_fk_flat_flat` (`flat_occ_id`),
  CONSTRAINT `flat_time_sch_table_flat_occ_id_4eb2dc14_fk_flat_flat` FOREIGN KEY (`flat_occ_id`) REFERENCES `flat_flat_occ_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `flat_time_sch_table` */

insert  into `flat_time_sch_table`(`id`,`date`,`from_time`,`to_time`,`visitor_name`,`no_of_member`,`status`,`flat_occ_id`) values 
(1,'27-09-2023','4:05','5:00','Shifa',4,'Accepted',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
